<!DOCTYPE html>
<html>
<head>
  <title>Donaciones - Victoria y libertad</title>
  <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">
  .navbar-default {
    background-image: none;
    border-radius: 0 !important;
    box-shadow: none;
    background: #fff !important;
}
.navbar-default .navbar-collapse, .navbar-default .navbar-form {
    padding: 17px 0;
    border-color: #e7e7e7;
}
.navbar-default .navbar-nav>li>a {
    color: #ff004b;
}
</style>

</head>
<body>
    <nav class="navbar navbar-default">
      <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">
            <img src="https://www.victoriaylibertad.org/wp-content/uploads/2019/09/logo-guillermo1.png" style="max-width: 150px">
          </a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

          <ul class="nav navbar-nav navbar-right">
            <li><a href="/">INICIO</a></li>
            <li><a href="#">NOSOTROS</a></li>
            <li><a href="#">CONTACTO</a></li>
          </ul>
        </div><!-- /.navbar-collapse -->
      </div><!-- /.container-fluid -->
    </nav>


    <section class="banner" style="margin-top: -20px">
      <img src="https://www.victoriaylibertad.org/wp-content/uploads/2019/10/BANNER_WEB.jpg" alt="donaciones fundacion victoria y libertad" style="display: block;width: 100%">
    </section>

    <section class="row" style="margin-top: 60px">
      <div class="container">
    
        <div class="col-md-6">
          <h3 style="color: #fa0145">Donaciones</h3>
          <p>
            Ayúdanos a ayudar. Tus donaciones harán que estas mujeres tengan vidas más justas y a su vez constribuyan a un cambio social equitativo. Sus vidas ya no deben estar rodeadas de dolor y sufrimiento.
          </p>
        </div>
        <div class="col-md-6">
          <h4 style="color: #fa0145">Formulario de donaciones</h4>
          <hr>
          <form class="formulario" method="post" action="">
            <div class="form-group">
              <span>Documento</span>
              <input type="text" name="documento" class="form-control">
            </div>
            <div class="form-group">
              <span>Concepto</span>
              <input type="text" name="concepto" class="form-control">
            </div>
            <div class="form-group">
              <span>Valor</span>
              <input type="number" name="valor" class="form-control">
            </div>
            <div class="form-group">
              <input type="submit" class="btn btn-danger">
            </div>
            <div class="form-group">
              
            </div>
          </form>
        </div>
        
      </div>
    </section>


<?php
if(!empty($_POST['valor'])){
  include_once("vendor/autoload.php");
        MercadoPago\SDK::setClientId("5284238287199205");
        MercadoPago\SDK::setClientSecret("SY5VBYRQXueyQKw5JmYxkx0uDDCh4k88");
        MercadoPago\SDK::setPublicKey("APP_USR-7661a28a-7408-46b6-b1e9-1433bec8de39");
        MercadoPago\SDK::setAccessToken("APP_USR-5284238287199205-102815-f20b9dd882b7c5cfe26a409d6caa7af5-480236855");

       $preference = new MercadoPago\Preference();

       $produto1 = ['BOLA DE FUTEBOL', 1, '109,90'];
       $produto2 = ['CHUTEIRA NIKE', 1, '100000'];
        
        # Building an item
        

        $item2 = new MercadoPago\Item();
        $item2->id = "00002";
        $item2->title = $produto2[0]; 
        $item2->quantity = $produto2[1];
        //$item2->currency_id = "COP";
        $item2->unit_price = $_POST['valor'];



        
        $preference->items = array($item2);
        
        $preference->save(); # Save the preference and send the HTTP Request to create
        
        # Return the HTML code for button
        
        //echo "<a href='$preference->sandbox_init_point'> Pagar </a>";
        header("Location: $preference->init_point");
 }
?>
</body>
</html>
